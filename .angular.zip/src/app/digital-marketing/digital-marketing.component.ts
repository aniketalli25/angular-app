import { Component } from '@angular/core';

@Component({
  selector: 'app-digital-marketing',
  standalone: true,
  imports: [],
  templateUrl: './digital-marketing.component.html',
  styleUrl: './digital-marketing.component.css'
})
export class DigitalMarketingComponent {

}
