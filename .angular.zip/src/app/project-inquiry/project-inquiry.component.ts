import { Component } from '@angular/core';

@Component({
  selector: 'app-project-inquiry',
  standalone: true,
  imports: [],
  templateUrl: './project-inquiry.component.html',
  styleUrl: './project-inquiry.component.css'
})
export class ProjectInquiryComponent {

}
